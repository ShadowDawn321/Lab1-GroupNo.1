
public class Problem2 {

	
	int month;
	int day;
	int year;
	
 Problem2 (int m, int d, int y){
		this.month = m;
		this.day = d;
		this.year = y;
		
	}
 
 public int compareTo(Problem2 time) {

	 if (this.year > time.year) {
		 return 1; 
	 }else if(this.month > time.month) {
		 return -1;
	 }else {
		 if (this.day > time.day) {
			 return 1;
	 	 }else if (this.day < time.day) {
			 return -1;
		 } else {
			 return 0;
		 }
	 }
 }
public String toString() {
	return "" + this.month + "/" + this.day + "/" + this.year;
}
}
