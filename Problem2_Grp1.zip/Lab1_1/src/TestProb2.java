 public class TestProb2 {

	public static void main(String[] args) {
		
		Problem2 d1 = new Problem2(7,7,2008);
		Problem2 d2 = new Problem2(5,5,2010);
		Problem2 d3 = new Problem2(9,23,2002);
		Problem2 d4 = new Problem2(8,20,2020);
		
		if(d1.compareTo(d2) == 1) { 
			System.out.println(d1 + " is more recent than " + d2);
		} else if(d1.compareTo(d2) == -1) { 
			System.out.println(d1 + " is later than " + d2);
		}else {
			System.out.println(d1 + " and " + d2 + " are the same dates...");
		}
		
		
		if(d3.compareTo(d4) == 1) { 
			System.out.println(d3 + " is more recent than " + d4);
		} else if(d3.compareTo(d2) == -1) {
			System.out.println(d3 + " is later than " + d4);
		}else {
			System.out.println(d3 + " and " + d4 + " are the same dates...");
		}
		
		
		
		
		
		
		
	}

}
