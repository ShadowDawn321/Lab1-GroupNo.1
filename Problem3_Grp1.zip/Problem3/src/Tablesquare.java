import java.util.*;
public class Tablesquare {

	public static void main(String[] args) {
		tableOfSquares(1,10);
	}
	
	static int count7(int n) {
		int count = 0;
		while(n>0) {
		if(n%10==7) {
			count++;
		
		}
		n = n /10;
	}
     return count;
	}	
   
    static int count7v2(int n) {
	   if(n==0) {
		return 0;
	}else if(n % 10 == 7) {
		return count7v2(n/10)+1;
	}else {
		return count7v2(n/10);
	}
	   
	   
	 }
		static void tableOfSquares(int n) {
			for(int i=1; i<=n; i++) {
				System.out.println(i+"   "+ i*i);
			}
		}
	
		static void tableOfSquares(int i, int n) {
			if(i<=n) {
				System.out.println(i+".) "+ i*i);
				tableOfSquares(i+1,n);
			}else {
				return;
			}
		}
}
