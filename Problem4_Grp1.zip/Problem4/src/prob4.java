import java.util.*;
public class prob4 {

	static void tableOfSquares(int N, int i) {
		if (i>N)
			return;
		System.out.println(i + " * " + i + " = " + i*i );
		
		
		tableOfSquares(N, ++i);
	}
	
	public static void main(String[] args) {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Numbers to Square: ");
		int x = s.nextInt();
		
		tableOfSquares(x, 1);
	}
	
	
}
